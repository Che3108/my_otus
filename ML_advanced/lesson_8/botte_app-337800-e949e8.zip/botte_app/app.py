import json

from bottle import route, run, template, static_file
from bottle import get, post, request, response

import recommends


@route('/')
def index():
    return """<h1>Hello I\'m simple recommend micro service!</h1>
    <p>visual <a href="/show/">/show/</a></p>
    <p>api <a href="/get-rec/">/get-rec/</a></p>"""


@route('/main_pics/<filename>')
def server_static(filename):
    return static_file(filename, root='../main_pics')


def prepare_ids(ids):
    ids = [int(i) for i in ids.split(',')]
    ids = [i for i in ids if i >= 0 and i < len(recommends.index)]
    return list(set(ids))


@get('/get-rec/')
def get_rec():
    response.content_type = 'application/json'
    try:
        initial_ids = str(request.query['ids'])
    except:
        res_send = {'status': 'error',
                    'message': 'need get parameter ?ids=1,2,3 ',
                    'result': []}
        return json.dumps(res_send, cls=recommends.NpEncoder)

    ids = prepare_ids(initial_ids)
    res = recommends.get_sim_mean(ids, recommends.vects, n=10)

    res_send = {'status': 'ok',
                'message': '',
                'result': res}
    return json.dumps(res_send, cls=recommends.NpEncoder)


@get('/show/')
def get_rec():
    try:
        initial_ids = str(request.query['ids'])
    except:
        return "add get parameter ?ids=1,2,3"
    ids = prepare_ids(initial_ids)
    res = recommends.get_sim_mean(ids, recommends.vects, n=10)
    files = recommends.get_im_by_indexes(res['similar_ind'], recommends.index)
    initial_files = recommends.get_im_by_indexes(ids, recommends.index)
    
    return template('show', initial_ids=initial_ids, reccomended_data=res, files=files, initial_files=initial_files)


if __name__ == '__main__':
    run(host='localhost', port=8080)
