import os
import json
import numpy as np


with open('./vects_q.npy', 'rb') as f:
    vects = np.load(f)
    
with open('./index.json', 'r') as f:
    index = json.load(f)


class NpEncoder(json.JSONEncoder):
    def default(self, obj):
        if isinstance(obj, np.integer):
            return int(obj)
        if isinstance(obj, np.floating):
            return float(obj)
        if isinstance(obj, np.ndarray):
            return obj.tolist()
        return super(NpEncoder, self).default(obj)


def get_similar(v, vects, n=10):
    scores = np.matmul(vects, v)
    
    scores = scores / 128
    
    top_similar_ind = (-scores).argsort()[:n]
    
    return {'similar_ind': list(top_similar_ind),
            'scores': list(scores[top_similar_ind])}


def get_im_by_indexes(inds, index):
    f_names = []
    for i in inds:
        f_names.append(f'../main_pics/{index[i]}_0.jpg')
    return f_names


def get_sim_mean(viewed_ids, vects, n=10):
    v = np.zeros(2048)
    viewed_ids = viewed_ids[::-1][:10]
    for i in viewed_ids[:]:
        v += vects[i]
    v = v / len(viewed_ids)
        
    v = v / np.linalg.norm(v)
    
    return filter_(get_similar(v, vects, n+len(viewed_ids)), viewed_ids)


def filter_(recommends, viewed_ids):
    res = {
        'similar_ind': [],
        'scores': []
    }

    for i in range(len(recommends['similar_ind'])):
        if recommends['similar_ind'][i] not in viewed_ids:
            res['similar_ind'].append(recommends['similar_ind'][i])
            res['scores'].append(recommends['scores'][i])
    return res
