from fastapi import FastAPI
from fastapi import File, UploadFile, Request, HTTPException, Depends
from fastapi.responses import HTMLResponse
from pydantic import BaseModel
from concurrent.futures import ThreadPoolExecutor, ProcessPoolExecutor

import vectorize_photos
import gpt3_complitions

db_pool = ThreadPoolExecutor(50, thread_name_prefix='db_pool')
exec_im_pool = ThreadPoolExecutor(100, thread_name_prefix='im_pool')
llm_pool = ProcessPoolExecutor(4)

app = FastAPI(debug=True)


class Text(BaseModel):
    text: str


def verify_token(req: Request):
    token = req.headers.get("access_token")
    valid = (token == '1234567890')
    if not valid:
        raise HTTPException(
            status_code=401,
            detail="Unauthorized"
        )
    return True


@app.get('/')
def main():
    html_content = """
        <h1>Мой микросервис</h1>
        <p>Векторизую фото, даю ответы</p>
        """
    return HTMLResponse(content=html_content, status_code=200)


@app.post('/send-photo')
async def process_photo(request: Request):
    verify_token(request)
    body = await request.body()
    request._body = body.replace(b'\r\n', b'\n').replace(b'\n', b'\r\n')

    data = await request.form()
    res = vectorize_photos.process_photo(data, db_pool, exec_im_pool)

    return res


@app.post('/complitions')
def get_complitions(text_r: Text, request: Request):
    verify_token(request)
    text_q = text_r.text
    f = llm_pool.submit(gpt3_complitions.generate, text=text_q,
                        model=gpt3_complitions.model, tokenizer=gpt3_complitions.tokenizer,
                        model_version=gpt3_complitions.model_version)
    res = f.result()

    # res = gpt3_complitions.generate(text_q, gpt3_complitions.model, gpt3_complitions.tokenizer,
    #                                 gpt3_complitions.model_version)

    return res
