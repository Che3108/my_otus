from transformers import AutoTokenizer, AutoModelForCausalLM

model_version = '0.0.1'
tokenizer = AutoTokenizer.from_pretrained("ai-forever/rugpt3small_based_on_gpt2")
model = AutoModelForCausalLM.from_pretrained("ai-forever/rugpt3small_based_on_gpt2")


def generate(text, model, tokenizer, model_version):
    text_tok = tokenizer.encode(text, return_tensors='pt')
    out = model.generate(text_tok, max_length=200, repetition_penalty=5., do_sample=True, top_k=5, top_p=0.8,
                         temperature=0.95)
    gen = tokenizer.decode(out[0])
    res = {
        'query': text,
        'complitions': gen,
        'model': model_version,
    }
    return res
