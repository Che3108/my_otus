import uuid
import json
import io
import pymysql
import numpy as np
import PIL
from concurrent.futures import ThreadPoolExecutor, ProcessPoolExecutor
import torch
from torchvision.models import resnet50, ResNet50_Weights
import torchvision.transforms.functional as transform


class Identity(torch.nn.Module):
    def __init__(self):
        super().__init__()

    def forward(self, x):
        return x

class NpEncoder(json.JSONEncoder):
    def default(self, obj):
        if isinstance(obj, np.integer):
            return int(obj)
        if isinstance(obj, np.floating):
            return float(obj)
        if isinstance(obj, np.ndarray):
            return obj.tolist()
        return super(NpEncoder, self).default(obj)


with open('./config.json', 'r') as f:
    json_config = json.load(f)

model = resnet50(weights=ResNet50_Weights.IMAGENET1K_V2)
model.fc = Identity()
model.eval()

weights = ResNet50_Weights.DEFAULT
preprocess = weights.transforms()


def im_vect(file_data):
    pil_img = PIL.Image.open(io.BytesIO(file_data))
    img = transform.to_tensor(pil_img)
    batch = preprocess(img).unsqueeze(0)
    with torch.no_grad():
        prediction = model(batch)
    vect = prediction.squeeze(0).numpy()

    return json.dumps(vect, cls=NpEncoder)


def save_to_db(data):
    data_to_insert = (data['img'], data['vect'], data['art'])
    with pymysql.connect(**json_config['db_conn']) as con:
        with con.cursor() as cur:
            q = """insert into test.images (img, vector, articul) values (%s,%s,%s)"""
            cur.execute(q, data_to_insert)
            inserted_id = cur.lastrowid
        con.commit()
    return inserted_id


def process_photo(data, db_pool: ThreadPoolExecutor = None, im_pool: ThreadPoolExecutor = None):
    art = json.loads(data['json'])['metadata']['art']

    file = data['files'].file
    im_name = str(uuid.uuid4())
    filename = f'./images/{im_name}.jpg'
    file_data = file.read()
    with open(filename, 'wb') as f:
        f.write(file_data)

    if im_pool:
        fut_vect = im_pool.submit(im_vect, file_data=file_data)
        vect = fut_vect.result()
    else:
        vect = im_vect(file_data)

    res_data = {
        'img': filename,
        'vect': vect,
        'art': art,
    }

    if db_pool:
        fut_db = db_pool.submit(save_to_db, res_data)
        inserted_id = fut_db.result()
    else:
        inserted_id = save_to_db(res_data)

    res_data['id'] = inserted_id

    return res_data
